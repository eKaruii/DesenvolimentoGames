using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float speed = 20.0f;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //move forward
        transform.Translate(0,0,1);
        transform.Translate(Vector3.forward * Time.deltaTime * speed);

        
    }
}
